package login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumLogin {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		
		
		
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///D:/share/hotelBooking/login.html/");
		
		System.out.println(driver.getCurrentUrl());
		
		String strheading=driver.findElement(By.xpath(".//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		
		
		
		if(strheading.contentEquals("Hotel Booking Application"))
			System.out.println("Heading Matched");
		else
			System.out.println("Heading Not Matched");
		
		Thread.sleep(1000);
		//driver.manage().timeouts().implicitlyWait(30,TimeUnit.MINUTES);
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		Thread.sleep(1000);
		//driver.manage().timeouts().implicitlyWait(3000,TimeUnit.MILLISECONDS);
		//driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		driver.findElement(By.name("userPwd")).sendKeys("ca12");
		Thread.sleep(1000);
		//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		driver.findElement(By.className("btn")).click();
		//Thread.sleep(1000);
		
		
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println(alertMsg);
		
		driver.switchTo().alert().accept();
		//driver.switchTo().alert().accept();
		//Thread.sleep(3000);
		
		//driver.navigate().to("file:///D:/share/hotelBooking/hotelbooking.html");
		//Thread.sleep(3000);

		//System.out.println(driver.getCurrentUrl());
		
		//driver.close();
		//driver.quit();

	}

}
