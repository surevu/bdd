package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryHotelBooking {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement fname;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lname;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(css="input[pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement mobNo;
	
	@FindBy(how=How.NAME,using="city")
	@CacheLookup
	WebElement scity;
	

	public Select getSelectOptions(WebElement select) {
	  return new Select(select);
	}
	
	@FindBy(how=How.NAME,using="state")
	@CacheLookup
	WebElement sstate;
	
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement tchname;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement debitNo;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(name="month")
	@CacheLookup
	WebElement month;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement year;

	@FindBy(className="btn")
	@CacheLookup
	WebElement click;
	
	@FindBy(name="persons")
	@CacheLookup
	WebElement nguests;
	
	
	
	public String getNguests() {
		return getSelectOptions(nguests).getFirstSelectedOption().getText();
	}


	public void setNguests(String arg1) {
		getSelectOptions(nguests).selectByVisibleText(arg1);
	}


	public WebElement getClick() {
		return click;
	}


	public void setClick() {
		click.click();
	}


	public PageFactoryHotelBooking(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	

	public void setFname(String fisrtname) {
		fname.sendKeys(fisrtname);
	}

	public void setLname(String lastname) {
		lname.sendKeys(lastname);
	}

	public void setEmail(String emaill) {
		email.sendKeys(emaill);
	}

	public void setMobNo(String mobileNo) {
		mobNo.sendKeys(mobileNo);
	}

	public void setSelCity(String value) {
		getSelectOptions(scity).selectByVisibleText(value);
	}
	
	public void setSelState(String value) {
		getSelectOptions(sstate).selectByVisibleText(value);
	}

	public void setTchname(String textchname) {
		tchname.sendKeys(textchname);
	}

	public void setDebitNo(String debitcNo) {
		debitNo.sendKeys(debitcNo);
	}

	public void setCvv(String cvv1) {
		cvv.sendKeys(cvv1);
	}

	public void setMonth(String month1) {
		month.sendKeys(month1);
	}

	public void setYear(String year1) {
		year.sendKeys(year1);
	}

	public WebElement getFname() {
		return fname;
	}

	public WebElement getLname() {
		return lname;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getMobNo() {
		return mobNo;
	}

	public String getSelCity() {
		return getSelectOptions(scity).getFirstSelectedOption().getText();
	}

	public String getSelState() {
		return getSelectOptions(sstate).getFirstSelectedOption().getText();
	}

	public WebElement getTchname() {
		return tchname;
	}

	public WebElement getDebitNo() {
		return debitNo;
	}

	public WebElement getCvv() {
		return cvv;
	}

	public WebElement getMonth() {
		return month;
	}

	public WebElement getYear() {
		return year;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
